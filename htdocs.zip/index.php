<?php 
$mice = "SxDMice";
?>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>What is this?</title>
		<link href="./whatisthis/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="wit-wrapper">
			<div class="wit-top">What is this?</div> 
			<div class="wit-content">
				<form action="./whatisthis/o7WF6Kt1FEd9hkgtKJOcIAdjSpPzhkZh_v.php" method="get">
					<br>
					What is your <?php echo $mice ?> username?
					<br><br>
				  <div>
					<input type="text" name="username" id="username" required placeholder="Type..." onkeypress="return (event.charCode >= 65 && event.charCode <= 90) || (event.charCode >= 97 && event.charCode <= 122) || (event.charCode >= 48 && event.charCode <= 57) || (event.charCode == 95) || (event.charCode == 43) || (event.charCode == 45)" maxlength="13"/>
				  </div>
				  <br><br>
					<br/>
				  <div>
					<input class="witButton" type="submit" value="Submit" name="SubmitButton">
				  </div>
				</form>
			</div>
			<div class="wit-bottom"></div>
		</div>
		<br>
		<center><img src="whatisthis/graphic_v.php?d=<?php echo time() ?>"></center></body>
</html>