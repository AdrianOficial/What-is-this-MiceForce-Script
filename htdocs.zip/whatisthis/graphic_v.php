<?php
//function by Adryan
include('../config.php');
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$sql = "SELECT COUNT(*) AS `count` FROM `table`";
$result = $conn->query($sql);
$row = mysqli_fetch_assoc($result);
$count = $row['count'];

function hexToColor($im,$hex){
    $hex = ltrim($hex,'#');
    $a = hexdec(substr($hex,0,2));
    $b = hexdec(substr($hex,2,2));
    $c = hexdec(substr($hex,4,2));
    return imagecolorallocate($im, $a, $b, $c); 
}
//

$im = imagecreate(250, 50);
$bg = hexToColor($im, '1D3C41');
$textcolor = hexToColor($im, '61bd6d');

if($count < 500) {
imagestring($im, 5, 0, 0, 'Total applications: '.$count.'/500', $textcolor);
}else{
imagestring($im, 5, 0, 0, '500 votes limit reached', $textcolor);
}
header('Content-type: image/png');

imagepng($im);
imagedestroy($im);
?>