<?php
$uName = $_GET['username'];
$ip = $_SERVER['REMOTE_ADDR'];
include('../config.php');

$conn1 = new mysqli($servername, $username, $password, $dbname);
if ($conn1->connect_error) {
    die("Connection failed: " . $conn1->connect_error);
} 

$sql = "SELECT Username FROM `table` WHERE Username = '".$uName."'";
$result = $conn1->query($sql);
$row = mysqli_fetch_assoc($result);
$count = $row['Username'];

if($count == $uName) {
	?>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>What is this?</title>
		<link href="../whatisthis/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="wit-wrapper">
			<div class="wit-top">What is this?</div> 
			<div class="wit-content">Error</div>
			<div class="wit-bottom"></div>		
		</div>
        <br>
		<<center><img src="../whatisthis/graphic_v.php?d=<?php echo time() ?>"></center></body>
	</body>
</html>
	<?php
	die;
}

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$sql = "INSERT INTO `table`(Username, IP) VALUES ('$uName', '$ip')";

if ($conn->query($sql) === TRUE) {
   ?>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>What is this?</title>
		<link href="../whatisthis/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="wit-wrapper">
			<div class="wit-top">What is this?</div> 
			<div class="wit-content">Succes</div>
			<div class="wit-bottom"></div>		
		</div>
        <br>
		<<center><img src="../whatisthis/graphic_v.php?d=<?php echo time() ?>"></center></body>
	</body>
</html>
   <?php
} else {
    ?>
<html>
	<head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>What is this?</title>
		<link href="../whatisthis/style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<div class="wit-wrapper">
			<div class="wit-top">What is this?</div> 
			<div class="wit-content">Error</div>
			<div class="wit-bottom"></div>		
		</div>
        <br>
		<<center><img src="../whatisthis/graphic_v.php?d=<?php echo time() ?>"></center></body>
	</body>
</html>
	<?php
}
$conn->close();
?>


